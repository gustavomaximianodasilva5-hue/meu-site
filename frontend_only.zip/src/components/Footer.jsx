import React from 'react';
import { Button } from './ui/button';
import { Zap, Phone, MapPin, Clock, Mail } from 'lucide-react';

const Footer = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <img 
                  src="https://customer-assets.emergentagent.com/job_cd7938c4-80e5-4343-83a5-1c219f4be53f/artifacts/ot3aw18h_channels4_profile%20%282%29.jpg" 
                  alt="CELESC" 
                  className="h-12 w-12 rounded-lg"
                />
                <div>
                  <h3 className="text-2xl font-bold text-celesc-orange">CELESC</h3>
                  <p className="text-gray-400 text-sm">Centrais Elétricas de Santa Catarina</p>
                </div>
              </div>
              
              <p className="text-gray-300 leading-relaxed mb-6 max-w-md">
                Há mais de 20 anos fornecendo energia para Santa Catarina. Oferecemos as melhores soluções 
                para renegociação de débitos e religação de energia elétrica.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  onClick={handleWhatsAppClick}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  WhatsApp
                </Button>
              </div>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-semibold mb-6 text-celesc-orange">Serviços</h4>
              <ul className="space-y-3">
                <li>
                  <button 
                    onClick={handleWhatsAppClick}
                    className="text-gray-300 hover:text-white transition-colors text-left"
                  >
                    Renegociação de Débitos
                  </button>
                </li>
                <li>
                  <button 
                    onClick={handleWhatsAppClick}
                    className="text-gray-300 hover:text-white transition-colors text-left"
                  >
                    Religação Imediata
                  </button>
                </li>
                <li>
                  <button 
                    onClick={handleWhatsAppClick}
                    className="text-gray-300 hover:text-white transition-colors text-left"
                  >
                    Parcelamento de Débitos
                  </button>
                </li>
                <li>
                  <button 
                    onClick={handleWhatsAppClick}
                    className="text-gray-300 hover:text-white transition-colors text-left"
                  >
                    Consultoria Especializada
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-lg font-semibold mb-6 text-celesc-orange">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-celesc-orange flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">(47) 99202-4837</p>
                    <p className="text-gray-400 text-sm">WhatsApp Oficial</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-celesc-orange flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">24 horas</p>
                    <p className="text-gray-400 text-sm">7 dias por semana</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-celesc-orange flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-medium">Santa Catarina</p>
                    <p className="text-gray-400 text-sm">Cobertura estadual completa</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Emergency Banner */}
        <div className="border-t border-gray-800 py-8">
          <div className="bg-gradient-to-r from-red-600/20 to-celesc-orange/20 rounded-2xl p-6 border border-red-600/30">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="flex items-center space-x-4 mb-4 md:mb-0">
                <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white">Emergência? Luz Cortada?</h4>
                  <p className="text-gray-300">Entre em contato imediatamente para religação urgente</p>
                </div>
              </div>
              
              <Button 
                onClick={handleWhatsAppClick}
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 font-bold whitespace-nowrap"
              >
                <Phone className="w-5 h-5 mr-2" />
                Religação Urgente
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-gray-800 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 CELESC - Centrais Elétricas de Santa Catarina. Todos os direitos reservados.
            </p>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <button onClick={handleWhatsAppClick} className="hover:text-white transition-colors">
                Política de Privacidade
              </button>
              <button onClick={handleWhatsAppClick} className="hover:text-white transition-colors">
                Termos de Uso
              </button>
              <button onClick={handleWhatsAppClick} className="hover:text-white transition-colors">
                Suporte
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;