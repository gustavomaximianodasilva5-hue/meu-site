import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CreditCard, Zap, Calculator, FileText, Phone, Clock } from 'lucide-react';

const Services = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  const services = [
    {
      icon: CreditCard,
      title: 'Renegociação de Débitos',
      description: 'Negocie seus débitos em aberto com as melhores condições de pagamento e descontos especiais.',
      features: ['Descontos de até 90%', 'Parcelamento em até 60x', 'Entrada facilitada', 'Processo 100% digital'],
      color: 'bg-blue-500'
    },
    {
      icon: Zap,
      title: 'Religação Imediata',
      description: 'Solicite a religação da sua energia elétrica de forma rápida e eficiente.',
      features: ['Religação em até 24h', 'Atendimento prioritário', 'Sem taxas extras', 'Confirmação por WhatsApp'],
      color: 'bg-green-500'
    },
    {
      icon: Calculator,
      title: 'Simulação de Parcelas',
      description: 'Calcule suas parcelas e encontre a melhor forma de quitar seus débitos.',
      features: ['Simulação instantânea', 'Diversas opções', 'Sem compromisso', 'Atendimento especializado'],
      color: 'bg-purple-500'
    }
  ];

  return (
    <section id="servicos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-celesc-orange/10 rounded-full border border-celesc-orange/20 mb-6">
            <FileText className="w-4 h-4 text-celesc-orange mr-2" />
            <span className="text-celesc-orange font-medium text-sm">Nossos Serviços</span>
          </div>
          
          <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-6">
            Soluções Completas para
            <span className="text-celesc-orange block">Seus Débitos Elétricos</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos as melhores condições do mercado para regularizar sua situação com a CELESC
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-500 border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-gray-900 group-hover:text-celesc-orange transition-colors">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <p className="text-gray-600 text-center leading-relaxed">
                    {service.description}
                  </p>
                  
                  <div className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        </div>
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    onClick={handleWhatsAppClick}
                    className="w-full bg-celesc-orange hover:bg-celesc-orange-dark text-white py-3 rounded-lg font-semibold transition-all duration-300 group-hover:shadow-lg"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Consultar Agora
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Emergency CTA */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-8 text-center text-white shadow-2xl">
          <div className="flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 mr-3" />
            <h3 className="text-2xl font-bold">Situação Crítica?</h3>
          </div>
          
          <p className="text-lg mb-6 opacity-90">
            Se sua energia foi cortada, entre em contato conosco imediatamente para religação urgente
          </p>
          
          <Button 
            onClick={handleWhatsAppClick}
            className="bg-white text-red-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-bold text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Zap className="w-5 h-5 mr-2" />
            Religação Urgente
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;