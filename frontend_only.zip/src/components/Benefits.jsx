import React from 'react';
import { Button } from './ui/button';
import { Shield, Clock, CreditCard, Users, CheckCircle, Phone } from 'lucide-react';

const Benefits = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  const benefits = [
    {
      icon: Shield,
      title: 'Processo Seguro e Oficial',
      description: 'Negociação direta com a CELESC, garantindo total segurança jurídica'
    },
    {
      icon: Clock,
      title: 'Atendimento 24 Horas',
      description: 'Suporte via WhatsApp disponível todos os dias da semana'
    },
    {
      icon: CreditCard,
      title: 'Condições Especiais',
      description: 'Descontos exclusivos e parcelamento facilitado para regularização'
    },
    {
      icon: Users,
      title: 'Equipe Especializada',
      description: 'Consultores especialistas em renegociação de débitos elétricos'
    }
  ];

  const stats = [
    { number: '+50.000', label: 'Clientes Atendidos', color: 'text-blue-600' },
    { number: '98%', label: 'Taxa de Aprovação', color: 'text-green-600' },
    { number: '24h', label: 'Tempo Máximo de Religação', color: 'text-celesc-orange' },
    { number: '90%', label: 'Desconto Máximo', color: 'text-purple-600' }
  ];

  return (
    <section id="beneficios" className="py-20 bg-white">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-celesc-orange/10 rounded-full border border-celesc-orange/20 mb-6">
            <CheckCircle className="w-4 h-4 text-celesc-orange mr-2" />
            <span className="text-celesc-orange font-medium text-sm">Por Que Escolher a CELESC</span>
          </div>
          
          <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-6">
            Benefícios Exclusivos
            <span className="text-celesc-orange block">Para Você</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mais de 20 anos de experiência oferecendo as melhores soluções energéticas para Santa Catarina
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {benefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-celesc-orange/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-celesc-orange group-hover:scale-110 transition-all duration-300">
                  <IconComponent className="w-8 h-8 text-celesc-orange group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-celesc-orange transition-colors">
                  {benefit.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-gray-50 to-orange-50 rounded-3xl p-8 lg:p-12 mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Números que Comprovam Nossa Excelência</h3>
            <p className="text-gray-600">Resultados que falam por si só</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className={`text-4xl lg:text-5xl font-bold ${stat.color} mb-2`}>
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-br from-celesc-orange to-celesc-orange-dark rounded-3xl p-8 lg:p-12 text-center text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="w-full h-full bg-white bg-opacity-5 bg-[radial-gradient(circle,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:30px_30px]"></div>
          </div>
          
          <div className="relative z-10">
            <h3 className="text-3xl lg:text-4xl font-bold mb-4">
              Pronto para Regularizar Seus Débitos?
            </h3>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Entre em contato conosco agora mesmo e descubra as melhores condições para quitar seus débitos com a CELESC
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleWhatsAppClick}
                className="bg-white text-celesc-orange hover:bg-gray-100 px-8 py-4 rounded-lg text-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <Phone className="w-5 h-5 mr-3" />
                Falar com Especialista
              </Button>
              
              <Button 
                onClick={handleWhatsAppClick}
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white hover:text-celesc-orange px-8 py-4 rounded-lg text-lg font-bold transition-all duration-300"
              >
                Simular Parcelas
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;