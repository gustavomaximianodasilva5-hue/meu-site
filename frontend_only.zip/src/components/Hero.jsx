import React from 'react';
import { Button } from './ui/button';
import { Zap, Clock, CreditCard, Phone } from 'lucide-react';

const Hero = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  return (
    <section className="relative bg-gradient-to-br from-white via-orange-50 to-white py-20 lg:py-32 overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-celesc-orange/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-celesc-orange/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 lg:px-6 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-4 py-2 bg-celesc-orange/10 rounded-full border border-celesc-orange/20">
                <Zap className="w-4 h-4 text-celesc-orange mr-2" />
                <span className="text-celesc-orange font-medium text-sm">Soluções Energéticas CELESC</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Renegociação de
                <span className="text-celesc-orange block">Débitos Elétricos</span>
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed">
                Regularize sua situação com a CELESC de forma rápida e segura. 
                Oferecemos as melhores condições para quitação de débitos e religação imediata.
              </p>
            </div>

            {/* Features highlights */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-celesc-orange/10 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-celesc-orange" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Religação Imediata</h3>
                  <p className="text-sm text-gray-600">Até 24 horas</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-celesc-orange/10 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-celesc-orange" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Condições Especiais</h3>
                  <p className="text-sm text-gray-600">Descontos e parcelamento</p>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleWhatsAppClick}
                size="lg" 
                className="bg-celesc-orange hover:bg-celesc-orange-dark text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <Phone className="w-5 h-5 mr-3" />
                Consultar Débitos
              </Button>
              
              <Button 
                onClick={handleWhatsAppClick}
                variant="outline" 
                size="lg" 
                className="border-2 border-celesc-orange text-celesc-orange hover:bg-celesc-orange hover:text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300"
              >
                Religação Imediata
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Atendimento 24h
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Processo 100% digital
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Seguro e confiável
              </div>
            </div>
          </div>

          {/* Visual Element */}
          <div className="relative">
            <div className="relative bg-gradient-to-br from-celesc-orange/20 to-celesc-orange/5 rounded-3xl p-8 backdrop-blur-sm border border-celesc-orange/20">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 bg-celesc-orange rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Central de Atendimento</h3>
                  <p className="text-gray-600">Especialistas prontos para ajudar você</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4">
                    <div className="text-2xl font-bold text-celesc-orange">+50k</div>
                    <div className="text-sm text-gray-600">Clientes atendidos</div>
                  </div>
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4">
                    <div className="text-2xl font-bold text-celesc-orange">98%</div>
                    <div className="text-sm text-gray-600">Satisfação</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;