import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Star, Quote, Phone } from 'lucide-react';

const Testimonials = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  const testimonials = [
    {
      name: 'Maria Silva',
      location: 'Florianópolis - SC',
      text: 'Consegui negociar minha dívida de R$ 3.500 por apenas R$ 800! O atendimento foi excelente e a religação foi feita no mesmo dia.',
      rating: 5,
      savings: 'Economia de 77%'
    },
    {
      name: 'João Santos',
      location: 'Joinville - SC',
      text: 'Estava com medo de ter a energia cortada novamente. A equipe da CELESC me ajudou a parcelar em 48x sem juros. Recomendo!',
      rating: 5,
      savings: 'Parcelado em 48x'
    },
    {
      name: 'Ana Costa',
      location: 'Blumenau - SC',
      text: 'Processo super rápido pelo WhatsApp. Em 2 dias já tinha tudo resolvido e minha energia religada. Obrigada pela atenção!',
      rating: 5,
      savings: 'Resolvido em 2 dias'
    }
  ];

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star 
        key={index} 
        className={`w-5 h-5 ${index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-white to-orange-50">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-celesc-orange/10 rounded-full border border-celesc-orange/20 mb-6">
            <Quote className="w-4 h-4 text-celesc-orange mr-2" />
            <span className="text-celesc-orange font-medium text-sm">Depoimentos</span>
          </div>
          
          <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-6">
            Histórias de Sucesso
            <span className="text-celesc-orange block">de Nossos Clientes</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Veja como ajudamos milhares de catarinenses a regularizar sua situação elétrica
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-2xl transition-all duration-500 group">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  {renderStars(testimonial.rating)}
                </div>
                
                <Quote className="w-8 h-8 text-celesc-orange/30 mb-4" />
                
                <p className="text-gray-700 leading-relaxed mb-6 italic">
                  "{testimonial.text}"
                </p>
                
                <div className="border-t pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.location}</p>
                    </div>
                    <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                      {testimonial.savings}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Social Proof */}
        <div className="text-center">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-8 inline-block shadow-lg">
            <div className="flex items-center justify-center space-x-8 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-celesc-orange mb-1">4.9/5</div>
                <div className="flex items-center justify-center mb-2">
                  {renderStars(5)}
                </div>
                <div className="text-sm text-gray-600">Avaliação média</div>
              </div>
              
              <div className="w-px h-16 bg-gray-300"></div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-celesc-orange mb-1">+2.500</div>
                <div className="text-sm text-gray-600 font-medium">Avaliações positivas</div>
              </div>
            </div>
            
            <Button 
              onClick={handleWhatsAppClick}
              className="bg-celesc-orange hover:bg-celesc-orange-dark text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              <Phone className="w-5 h-5 mr-2" />
              Seja o Próximo Caso de Sucesso
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;