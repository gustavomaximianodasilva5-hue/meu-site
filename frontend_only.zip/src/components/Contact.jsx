import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Phone, Clock, MapPin, MessageCircle, Zap, CreditCard } from 'lucide-react';

const Contact = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'WhatsApp Oficial',
      info: '(47) 99202-4837',
      description: 'Atendimento imediato via WhatsApp'
    },
    {
      icon: Clock,
      title: 'Horário de Funcionamento',
      info: '24 horas por dia',
      description: '7 dias por semana'
    },
    {
      icon: MapPin,
      title: 'Região de Atendimento',
      info: 'Todo Santa Catarina',
      description: 'Cobertura estadual completa'
    }
  ];

  const quickServices = [
    {
      icon: CreditCard,
      title: 'Renegociação Express',
      description: 'Negocie seus débitos em minutos',
      action: 'Negociar Agora'
    },
    {
      icon: Zap,
      title: 'Religação Urgente',
      description: 'Religação em até 24 horas',
      action: 'Solicitar Religação'
    }
  ];

  return (
    <section id="contato" className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-celesc-orange-dark relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-32 h-32 bg-white rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-celesc-orange rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 lg:px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-white/10 rounded-full border border-white/20 mb-6">
            <MessageCircle className="w-4 h-4 text-white mr-2" />
            <span className="text-white font-medium text-sm">Entre em Contato</span>
          </div>
          
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6">
            Fale Conosco Agora
            <span className="text-celesc-orange block">e Resolva Hoje Mesmo</span>
          </h2>
          
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Nossa equipe está pronta para ajudar você a regularizar sua situação com a CELESC
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Informações de Contato</h3>
              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const IconComponent = info.icon;
                  return (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-celesc-orange/20 rounded-xl flex items-center justify-center flex-shrink-0">
                        <IconComponent className="w-6 h-6 text-celesc-orange" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white mb-1">{info.title}</h4>
                        <p className="text-celesc-orange font-medium text-lg">{info.info}</p>
                        <p className="text-gray-400 text-sm">{info.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Services */}
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Serviços Rápidos</h3>
              <div className="space-y-4">
                {quickServices.map((service, index) => {
                  const IconComponent = service.icon;
                  return (
                    <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-celesc-orange rounded-lg flex items-center justify-center">
                              <IconComponent className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-white">{service.title}</h4>
                              <p className="text-gray-300 text-sm">{service.description}</p>
                            </div>
                          </div>
                          <Button 
                            onClick={handleWhatsAppClick}
                            className="bg-celesc-orange hover:bg-celesc-orange-dark text-white"
                          >
                            {service.action}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main CTA Card */}
          <div className="lg:sticky lg:top-8">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-2xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-celesc-orange rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-white">
                  Atendimento Especializado
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="text-center text-gray-300">
                  <p className="mb-4">
                    Clique no botão abaixo para iniciar uma conversa no WhatsApp com nossa equipe especializada
                  </p>
                  
                  <div className="flex items-center justify-center space-x-4 text-sm mb-6">
                    <div className="flex items-center text-green-400">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                      Online agora
                    </div>
                    <div className="text-gray-400">•</div>
                    <div className="text-gray-300">Resposta imediata</div>
                  </div>
                </div>
                
                <Button 
                  onClick={handleWhatsAppClick}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-4 text-lg font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                >
                  <Phone className="w-6 h-6 mr-3" />
                  Iniciar Conversa no WhatsApp
                </Button>
                
                <div className="text-center text-xs text-gray-400">
                  Ao clicar, você será direcionado para o WhatsApp oficial da CELESC
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;