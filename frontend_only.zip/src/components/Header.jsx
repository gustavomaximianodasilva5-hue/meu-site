import React, { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X, Phone } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/5547992024837?text=Ol%C3%A1%2C%20Solicito%20Atendimento%20Celesc', '_blank');
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src="https://customer-assets.emergentagent.com/job_cd7938c4-80e5-4343-83a5-1c219f4be53f/artifacts/ot3aw18h_channels4_profile%20%282%29.jpg" 
              alt="CELESC" 
              className="h-10 w-10 rounded-lg"
            />
            <div>
              <h1 className="text-xl font-bold text-celesc-orange">CELESC</h1>
              <p className="text-xs text-gray-600">Renegociação de Débitos</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#servicos" className="text-gray-700 hover:text-celesc-orange transition-colors font-medium">
              Serviços
            </a>
            <a href="#beneficios" className="text-gray-700 hover:text-celesc-orange transition-colors font-medium">
              Benefícios
            </a>
            <a href="#contato" className="text-gray-700 hover:text-celesc-orange transition-colors font-medium">
              Contato
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center space-x-4">
            <Button 
              onClick={handleWhatsAppClick}
              className="bg-celesc-orange hover:bg-celesc-orange-dark text-white px-6 py-2 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <Phone className="w-4 h-4 mr-2" />
              Atendimento
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-3">
              <a 
                href="#servicos" 
                className="text-gray-700 hover:text-celesc-orange transition-colors py-2 px-4 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Serviços
              </a>
              <a 
                href="#beneficios" 
                className="text-gray-700 hover:text-celesc-orange transition-colors py-2 px-4 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Benefícios
              </a>
              <a 
                href="#contato" 
                className="text-gray-700 hover:text-celesc-orange transition-colors py-2 px-4 rounded-lg hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </a>
              <Button 
                onClick={handleWhatsAppClick}
                className="bg-celesc-orange hover:bg-celesc-orange-dark text-white mt-3 mx-4"
              >
                <Phone className="w-4 h-4 mr-2" />
                Atendimento WhatsApp
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;